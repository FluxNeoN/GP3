<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<style>
		h1 { text-align: center; 	font-family: Calibri; }
	</style>
</head>
<body>

<h1>Just a blank page</h1>
    
</body>
</html>
